function test_write()
fid = fopen('screw.instr','rt');
tmp = textscan(fid,'%s','Delimiter','\n');
fclose(fid);
for i=1:length(tmp{1,1})
    if isempty(char(tmp{1,1}(i))) == 1
        dlmwrite('test4.txt',' ','-append','delimiter','')
    else
        dlmwrite('test4.txt',char(tmp{1,1}(i)),'-append','delimiter','')
    end
end