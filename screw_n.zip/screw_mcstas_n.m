function screw_mcstas_n()
L = 30;
lambda = 5;
m = 6;
w = 0.03;
h = 0.2;
ncount = 1e5;
lr = 1;
for i=1:45
    f = -90/i;
    screw(w,h,L,f);
    screw_n(i);
    [p1,m1]=mcstas('screw_n.instr',struct('L',L,'lambda',lambda,'guide_m',m,'w',w,'h',h,'phi',f),struct('ncount',ncount,'mpi',4));
    Il(lr)=p1(1,:,:).Signal;
    lr=lr+1;
end
figure;
plot(L,Il)
xlabel('n')
ylabel('I_{screw}')
title(join(['Divergence = \pm1.5\circ, ','lambda = ',string(lambda)]))
grid on
savefig(join(['screw_n','lambda',string(lambda),'l'],'_'));
end