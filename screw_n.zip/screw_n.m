function screw_n(n)
fid = fopen('screw_part1.instr','rt');
tmp = textscan(fid,'%s','Delimiter','\n');
fclose(fid);
for i=1:length(tmp{1,1})
    if isempty(char(tmp{1,1}(i))) == 1
        dlmwrite('screw_n.instr',' ','-append','delimiter','')
    else
        dlmwrite('screw_n.instr',char(tmp{1,1}(i)),'-append','delimiter','')
    end
end
a = 'COMPONENT COPY(screw) = COPY(screw)()';
b = '  AT (0, 0, L+0.0001) RELATIVE PREVIOUS';
c = '  ROTATED (0,0,phi) RELATIVE PREVIOUS';
if n>1
    for i = 1:n-1
        dlmwrite('screw_n.instr',a,'-append','delimiter','')
        dlmwrite('screw_n.instr',b,'-append','delimiter','')
        dlmwrite('screw_n.instr',c,'-append','delimiter','')
        dlmwrite('screw_n.instr',' ','-append','delimiter','\n')
    end
end
fid = fopen('screw_part2.instr','rt');
tmp = textscan(fid,'%s','Delimiter','\n');
fclose(fid);
for i=1:length(tmp{1,1})
    if isempty(char(tmp{1,1}(i))) == 1
        dlmwrite('screw_n.instr',' ','-append','delimiter','')
    else
        dlmwrite('screw_n.instr',char(tmp{1,1}(i)),'-append','delimiter','')
    end
end